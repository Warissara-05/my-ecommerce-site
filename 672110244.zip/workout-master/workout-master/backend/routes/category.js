const express = require('express');
const router = express.Router();  

const category_file = require('../../json/occupation-cat.json');

router.get('/', (req, res) => {
    res.json(category_file);
});

module.exports = router;